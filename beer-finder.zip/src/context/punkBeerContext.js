import { createContext } from 'react';

const punkBeerContext = createContext();

export default punkBeerContext;
