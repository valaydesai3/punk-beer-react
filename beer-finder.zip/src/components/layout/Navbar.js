import React from 'react';

const Navbar = () => {
  return (
    <nav className="navbar">
      <h1>Beer Finder</h1>
    </nav>
  );
};

export default Navbar;
